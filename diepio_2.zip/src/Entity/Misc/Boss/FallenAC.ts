import GameServer from "../../../Game";
import Barrel from "../../Tank/Barrel";
import TankDefinitions from "../../../Const/TankDefinitions";
import AbstractBoss from "../../Boss/AbstractBoss";

import { Tank } from "../../../Const/Enums";
import { AIState } from "../../AI";
/**
 * Class which represents a funny Fallen AC boss
 */
export default class FallenAC extends AbstractBoss {

    public constructor(game: GameServer) {
        super(game);

        this.nameData.values.name = 'Fallen Arena Closer';
        this.movementSpeed = 20;
        for (const barrelDefinition of TankDefinitions[Tank.ArenaCloser].barrels) {
            this.barrels.push(new Barrel(this, barrelDefinition));
        }
    }

    public get sizeFactor() {
        return this.physicsData.values.size / 50;
    }

    protected moveAroundMap() {
        if (this.ai.state === AIState.idle) {
            this.positionData.angle += this.ai.passiveRotation;
            this.accel.set({x: 0, y: 0});
        } else {
            const x = this.positionData.values.x,
                  y = this.positionData.values.y;

            this.positionData.angle = Math.atan2(this.ai.inputs.mouse.y - y, this.ai.inputs.mouse.x - x);
        }
    }

    public tick(tick: number) {
        super.tick(tick);
    }
}
