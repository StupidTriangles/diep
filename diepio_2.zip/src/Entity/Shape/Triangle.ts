import GameServer from "../../Game";
import AbstractShape from "./AbstractShape";

import { Color } from "../../Const/Enums";

export default class Triangle extends AbstractShape {
    public constructor(game: GameServer, shiny=Math.random() < 0.000001) {
        super(game);
        
        this.nameData.values.name = "Triangle";
        this.healthData.values.health = this.healthData.values.maxHealth = 30;
        this.physicsData.values.size = 55 * Math.SQRT1_2;
        this.physicsData.values.sides = 3;
        this.styleData.values.color = shiny ? Color.Shiny : Color.EnemyTriangle;

        this.damagePerTick = 8;
        this.scoreReward = 25;
        this.isShiny = shiny;

        if (shiny) {
            this.scoreReward *= 100;
            this.healthData.values.health = this.healthData.values.maxHealth *= 10;
        }
    }
}
