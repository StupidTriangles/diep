import ObjectEntity from "../Entity/Object";

export default interface CollisionManager {
    reset(bottomY: number, rightX: number): void;
    insertEntity(entity: ObjectEntity): void;
    retrieve(x: number, y: number, radiW: number, radiH: number): ObjectEntity[];
    retrieveEntitiesByEntity(entity: ObjectEntity): ObjectEntity[];
}