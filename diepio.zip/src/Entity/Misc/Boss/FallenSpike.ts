import GameServer from "../../../Game";
import { AIState } from "../../AI";
import AbstractBoss from "../../Boss/AbstractBoss";

import { AddonById } from "../../Tank/Addons";

/**
 * Class which represents the a funny Fallen Spike boss
 */
export default class FallenSpike extends AbstractBoss {
    public constructor(game: GameServer) {
        super(game);

        this.movementSpeed = 3.0;

        this.nameData.values.name = 'Fallen Spike';

        // Sharp
        this.damagePerTick *= 2;

        if (AddonById.spike) new AddonById['spike'](this);
    }

    public get sizeFactor() {
        return this.physicsData.values.size / 50;
    }

    protected moveAroundMap() {
        if (this.ai.state === AIState.idle) {
            this.positionData.angle += this.ai.passiveRotation;
            this.accel.set({x: 0, y: 0});
        } else {
            const x = this.positionData.values.x,
                  y = this.positionData.values.y;

            this.positionData.angle = Math.atan2(this.ai.inputs.mouse.y - y, this.ai.inputs.mouse.x - x);
        }
    }

    public tick(tick: number) {
        super.tick(tick);
    }
}
