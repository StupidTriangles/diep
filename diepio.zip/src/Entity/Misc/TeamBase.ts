import GameServer from "../../Game";

import { HealthFlags, PhysicsFlags, StyleFlags } from "../../Const/Enums";
import { TeamGroupEntity } from "./TeamEntity";
import LivingEntity from "../Live";
/**
 * Represents Team Bases in game.
 */
export default class TeamBase extends LivingEntity {

    public constructor(game: GameServer, team: TeamGroupEntity, x: number, y: number, width: number, height: number, painful: boolean=true) {
        super(game);

        this.relationsData.values.team = team;

        this.positionData.values.x = x;
        this.positionData.values.y = y;

        this.physicsData.values.width = width;
        this.physicsData.values.size = height;
        this.physicsData.values.sides = 2;
        this.physicsData.values.flags |= PhysicsFlags.showsOnMap | PhysicsFlags.noOwnTeamCollision | PhysicsFlags.isBase;
        this.physicsData.values.pushFactor = 2;
        this.damagePerTick = 5;

        if (!painful) {
            this.physicsData.values.pushFactor = 0;
            this.damagePerTick = 0;
        }

        this.damageReduction = 0;
        this.physicsData.values.absorbtionFactor = 0;

        this.styleData.values.opacity = 0.1;
        this.styleData.values.borderWidth = 0;
        this.styleData.values.color = team.teamData.teamColor;
        this.styleData.values.flags |= StyleFlags._minimap | StyleFlags.hasNoDmgIndicator;

        this.healthData.flags |= HealthFlags.hiddenHealthbar
        this.healthData.health = this.healthData.values.maxHealth = 0xABCFF;
    }

    public tick(tick: number) {
        // No animation. No regen
        this.lastDamageTick = tick;
    }
}
